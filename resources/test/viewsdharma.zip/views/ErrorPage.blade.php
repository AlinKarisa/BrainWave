<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <div style="text-align:center">
      <h1>403</h1>
      <H6>FORBIDDEN</H6>
      <h5>Anda Tidak Dapat Mengakses Halaman Ini!</h5>
  </div>
</body>
</html>